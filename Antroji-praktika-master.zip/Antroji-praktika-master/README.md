# Antroji-praktika

Sistema leidžia bendrauti su duomenų baze: matyti, kurti, pašalinti įrašus ir kt.
